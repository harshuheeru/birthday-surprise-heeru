# Birthday Surprise — Heeru

Open `index.html` in Chrome/Edge.

## Included
- 6 personal photos in `assets/photo1.jpg` … `photo6.jpg`
- Birthday song in `assets/dil-dhadakta-hai.mp3`
- NEXT navigation after each section
- Faster message typing
- Music play/pause button

## Note
The browser may block automatic audio until the first user interaction. The first **Open Your Surprise** click starts the song; the floating 🎵 button can also start/pause it.
